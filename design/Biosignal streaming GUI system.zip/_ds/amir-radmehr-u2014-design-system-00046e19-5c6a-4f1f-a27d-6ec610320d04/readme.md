# Amir Radmehr — Design System

A design system for **Amir Radmehr's personal academic website** — a minimalist,
polished PhD portfolio with a quiet *2000s-coding* personality (terminal panels,
monospace kickers, a blinking cursor, a faint blueprint grid) and a live
**four-season** accent theme. Built to feel modern, calm, and a little playful.

> **Source:** This system is derived from the live site repository
> [`amiradmehr/amiradmehr.github.io`](https://github.com/amiradmehr/amiradmehr.github.io)
> (a Hugo + PaperMod static site, `baseURL: https://amiradmehr.com`). Explore that
> repo to go deeper — the seasonal logic lives in `assets/css/extended/seasons.css`
> and `layouts/partials/header.html`; the homepage in `layouts/index.html`. The
> author is **Amir Radmehr**, a PhD student in Computer Science at **UMass Amherst**
> (Wireless and Sensor Systems Lab), researching cyber-physical systems, wearable
> health, and embedded ML.

---

## Content fundamentals — how the copy reads

- **Voice:** first person, warm but precise. "I build wearable systems that measure
  blood pressure continuously." Confident, never boastful.
- **Casing:** sentence case everywhere in UI and prose. The **only** uppercase is the
  mono *kicker* labels (`// 02 · STACK`) — and those are a deliberate code motif.
- **Person:** **I / my** for the author; **you** is rare (used only in CTAs like
  "Get in touch").
- **Tone:** plain-spoken and technical. Real nouns — *ESP32-S3, 100 Hz, PPG, BLE* —
  never marketing fluff. Numbers are concrete and unit-bearing.
- **Mono asides:** short lowercase fragments framed as code or comments —
  `~/amir`, `$ whoami`, `# updated this term`, `./me.jpeg`. They carry the
  personality; keep them terse and never shouty.
- **Emoji:** **none.** The original homepage used emoji section headings
  (🔭 🛠️ 📝 ⭐); this system **replaces them** with mono kickers for a cleaner,
  more coherent, more "engineer" feel. Do not reintroduce emoji into UI chrome.
- **Headings:** noun phrases, title-less of punctuation. "Featured Projects",
  "Currently Working On", "Get in touch".

## Visual foundations

- **Color & mode.** Dark is the default; a sun/moon toggle flips to light. Surfaces
  are owned by light/dark (`--theme` page, `--entry` card, `--code-bg` sunken,
  `--code-block-bg` terminal). Neutrals are slightly cool grays, never pure black.
- **Seasonal accent.** A single `--accent` recolours links, pills, focus rings,
  underlines, and the soft `--season-grad` corner wash. It is set at runtime from
  the **calendar month** (N. Hemisphere): **spring** fresh grass-green · **summer**
  electric turquoise (Caribbean water — bright, cool, deliberately *not* warm) ·
  **autumn** golden amber/rust · **winter** deep icy blue. Hues are spread around the
  wheel so no two seasons read alike (summer's teal and winter's blue stay clearly
  apart). Autumn is the default / home colour (it matches the carpet and the author's
  autumn portrait). Dark-mode season values are brighter siblings of the light ones.
- **Type.** Three families. **Newsreader** (serif) for the hero name and every
  section heading — it gives the academic warmth. **Inter** (sans) for all body and
  UI. **JetBrains Mono** for the coding touch: kickers, meta/dates, kbd tokens,
  terminal panels. Body is 17px at 1.7 leading; headings carry tight tracking
  (`-0.012em`).
- **Backgrounds.** Two quiet layers, both behind content: a faint **22px blueprint
  grid** (`.grid-bg`) and the **seasonal gradient wash** (`--season-grad`). The
  **Persian-carpet band** sits behind the frosted nav at ~5% opacity — a heritage
  nod, used only as a thin band, never full-bleed. (Earlier drifting seasonal
  particles were removed — the season now lives purely in colour.)
- **Cards.** Soft, not loud: `--entry` fill, 1px `--border` hairline, 12px radius,
  `--shadow-sm` at rest. On hover they lift `translateY(-3/-4px)`, swap to
  `--shadow-lg`, and the border + title shift to the accent. Project covers zoom
  `scale(1.06)`.
- **Buttons & pills.** Fully rounded (`--radius-pill`). Primary = filled accent +
  white; secondary = accent tint + accent border; ghost = hairline outline. Skill
  pills are neutral and lift to the accent tint on hover.
- **Terminal panels.** The signature element — a dark card (always dark, both modes)
  with mac traffic lights, a `amir@radmehr: ~` prompt label, mono body, green `$`
  prompts, dimmed `#` comments, and a blinking accent cursor.
- **Motion.** Calm and short. `--ease` `cubic-bezier(.22,.61,.36,1)`, `--dur` 0.22s.
  Hover = lift + color; entrances = fadeInUp ~0.4–0.6s; the cursor blinks at 1.1s
  steps. Everything collapses under `prefers-reduced-motion`.
- **Borders & radii.** Hairline 1px dividers; radii 4 (chips/code) · 8 (inputs) ·
  12 (cards) · pill. Section headings use a hairline rule with a 46px accent
  underline segment.
- **Imagery.** Warm and autumnal — the portrait, the carpet reds/ambers. Photos get
  a 12px radius + `--shadow-lg` and a mono filename caption (`./me.jpeg`).

## Iconography

- **Social/UI icons** are a small, consistent inline-SVG set drawn in the kit
  (`chrome.jsx`): email, GitHub, LinkedIn, Google Scholar, CV. GitHub/LinkedIn/
  Scholar are solid brand-style glyphs; email/CV are 1.8px line icons. They live in
  pill chips that lift to the accent on hover. *Substitution note:* the source repo
  ships PaperMod's full SVG sprite (`layouts/partials/svg.html`, 178 KB) — too heavy
  to import — so these are clean hand-matched equivalents at the same scale.
- **Flag marks.** Two real SVGs from the site sit in the nav / brand cards:
  `persian_flag_icon.svg` (Iran) and `us_flag.svg` — heritage + location. Rendered
  as 22px circles.
- **Favicon** is `favicon-32x32.png` (carried from the site).
- **No emoji in chrome.** The only glyphs used as ornament are the `~/` `$` `#`
  characters that are *type*, not icons.
- **The arrow** on external buttons is the site's own corner-arrow SVG (box +
  diagonal), kept verbatim.

## Caveats & substitutions

- **JetBrains Mono** is loaded from Google Fonts (CDN) — the source repo ships **no
  monospace face**, and the coding touch needs one. If you'd prefer a self-hosted
  mono (or a different one — Berkeley Mono, Commit Mono, IBM Plex Mono), send the
  font file and I'll swap it in `tokens/fonts.css`.
- Inter & Newsreader are the **real self-hosted woff2** files from the site.
- Project/paper imagery in the kit uses the **carpet textures as placeholders** —
  swap in real project covers when available.

---

## Index — what's in this system

**Foundations**
- `styles.css` — the single entry point (an `@import` manifest). Consumers link this.
- `tokens/fonts.css` — `@font-face` (Inter, Newsreader) + JetBrains Mono import.
- `tokens/colors.css` — surfaces, text, lines, carpet + terminal palettes, semantic aliases.
- `tokens/typography.css` — families, fluid scale, weights, leading, tracking.
- `tokens/spacing.css` — spacing, widths, radius, elevation, motion, `.grid-bg`.
- `tokens/seasons.css` — the four-season accent system + `--season-grad`.

**Components** (`components/`, `window.<Namespace>` after compile)
- `core/Button` — pill action button (primary / secondary / ghost, mono, external).
- `core/Badge` — skill pill · tag chip · mono meta token.
- `core/SectionHeading` — serif heading + accent underline + mono kicker.
- `core/TerminalBlock` (+ `.Line`) — the signature terminal panel with cursor.
- `content/ProjectCard` — featured-project tile.
- `content/PostCard` — recent-post row.

**UI kit** (`ui_kits/website/`)
- `index.html` — interactive full-site recreation: Home, Papers (split-pane),
  Projects, Blog, Teaching, Contact, with the live season + light/dark toggle.

**Specimen cards** (`guidelines/*.card.html`) — populate the Design System tab
(Colors, Type, Spacing, Brand).

**Skill** — `SKILL.md` makes this downloadable as a Claude Code Agent Skill.
