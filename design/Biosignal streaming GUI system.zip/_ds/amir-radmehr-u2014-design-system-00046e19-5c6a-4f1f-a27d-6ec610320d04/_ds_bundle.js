/* @ds-bundle: {"format":3,"namespace":"AmirRadmehrU2014DesignSystem_00046e","components":[{"name":"PostCard","sourcePath":"components/content/PostCard.jsx"},{"name":"ProjectCard","sourcePath":"components/content/ProjectCard.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"SectionHeading","sourcePath":"components/core/SectionHeading.jsx"},{"name":"TerminalBlock","sourcePath":"components/core/TerminalBlock.jsx"}],"sourceHashes":{"components/content/PostCard.jsx":"029b10b02990","components/content/ProjectCard.jsx":"3257fd4eb9d5","components/core/Badge.jsx":"12cb75762caa","components/core/Button.jsx":"3df07dfac804","components/core/SectionHeading.jsx":"ebeba2b4d256","components/core/TerminalBlock.jsx":"4e631dad35ea","ui_kits/website/app.jsx":"893cbe620947","ui_kits/website/chrome.jsx":"f334df64add9","ui_kits/website/content.jsx":"d306a9ad9714","ui_kits/website/screens.jsx":"dbf90d12f441","ui_kits/website/ui.jsx":"83239518f87f"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.AmirRadmehrU2014DesignSystem_00046e = window.AmirRadmehrU2014DesignSystem_00046e || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Badge — small inline label.
 *  - tone="skill"  → neutral pill (skills & tools grid)
 *  - tone="tag"    → accent-tinted chip (post / project tags)
 *  - tone="mono"   → monospace meta token (kbd, venue, status)
 * Skill pills lift on hover; tag/mono are static.
 */
function Badge({
  children,
  tone = 'skill',
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    lineHeight: 1,
    whiteSpace: 'nowrap',
    transition: 'background var(--dur) var(--ease), color var(--dur) var(--ease), border-color var(--dur) var(--ease), transform var(--dur) var(--ease)'
  };
  const tones = {
    skill: {
      padding: '6px 13px',
      borderRadius: 'var(--radius-pill)',
      background: 'var(--surface-sunken)',
      border: '1px solid var(--line)',
      color: 'var(--text-muted)',
      fontSize: '0.84rem',
      fontWeight: 500,
      cursor: 'default',
      ...(hover ? {
        background: 'var(--accent-tint)',
        borderColor: 'var(--accent-border)',
        color: 'var(--accent)',
        transform: 'translateY(-2px)'
      } : {})
    },
    tag: {
      padding: '3px 11px',
      borderRadius: 'var(--radius-pill)',
      background: 'var(--accent-tint)',
      color: 'var(--accent)',
      fontSize: '0.74rem',
      fontWeight: 500
    },
    mono: {
      padding: '4px 9px',
      borderRadius: 'var(--radius-xs)',
      background: 'var(--surface-sunken)',
      border: '1px solid var(--line)',
      color: 'var(--text-muted)',
      fontFamily: 'var(--font-mono)',
      fontSize: '0.72rem',
      letterSpacing: 'var(--tracking-mono)'
    }
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      ...base,
      ...tones[tone],
      ...style
    },
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false)
  }, rest), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/content/PostCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * PostCard — a recent-post row: mono date + tag chips on a meta line,
 * then title and a one-line summary. Lifts on hover; title turns accent.
 */
function PostCard({
  title,
  summary,
  date,
  tags = [],
  href = '#',
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("a", _extends({
    href: href,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'block',
      padding: '18px 22px',
      borderRadius: 'var(--radius-md)',
      background: 'var(--surface-card)',
      border: `1px solid ${hover ? 'var(--accent-border)' : 'var(--line)'}`,
      boxShadow: hover ? 'var(--shadow-lg)' : 'var(--shadow-sm)',
      textDecoration: 'none',
      transform: hover ? 'translateY(-3px)' : 'none',
      transition: 'transform var(--dur) var(--ease), box-shadow var(--dur) var(--ease), border-color var(--dur) var(--ease)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '10px',
      flexWrap: 'wrap'
    }
  }, date && /*#__PURE__*/React.createElement("time", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-meta)',
      color: 'var(--text-muted)',
      letterSpacing: 'var(--tracking-mono)'
    }
  }, date), tags.length > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      gap: '6px'
    }
  }, tags.map(t => /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    key: t,
    tone: "tag"
  }, t)))), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: '1.08rem',
      fontWeight: 600,
      margin: '7px 0 4px',
      color: hover ? 'var(--accent)' : 'var(--text-strong)',
      transition: 'color var(--dur) var(--ease)'
    }
  }, title), summary && /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-small)',
      color: 'var(--text-muted)',
      margin: 0,
      lineHeight: 1.55
    }
  }, summary));
}
Object.assign(__ds_scope, { PostCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/PostCard.jsx", error: String((e && e.message) || e) }); }

// components/content/ProjectCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * ProjectCard — featured-project tile: cover thumbnail, title, summary,
 * tag chips. Lifts and reveals the accent on hover; the cover zooms.
 */
function ProjectCard({
  title,
  summary,
  image,
  tags = [],
  href = '#',
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("a", _extends({
    href: href,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'flex',
      flexDirection: 'column',
      borderRadius: 'var(--radius-md)',
      background: 'var(--surface-card)',
      border: `1px solid ${hover ? 'var(--accent-border)' : 'var(--line)'}`,
      boxShadow: hover ? 'var(--shadow-lg)' : 'var(--shadow-sm)',
      overflow: 'hidden',
      textDecoration: 'none',
      transform: hover ? 'translateY(-4px)' : 'none',
      transition: 'transform var(--dur) var(--ease), box-shadow var(--dur) var(--ease), border-color var(--dur) var(--ease)',
      ...style
    }
  }, rest), image && /*#__PURE__*/React.createElement("div", {
    style: {
      height: '150px',
      overflow: 'hidden',
      background: 'var(--surface-sunken)'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: image,
    alt: title,
    loading: "lazy",
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      transform: hover ? 'scale(1.06)' : 'none',
      transition: 'transform 0.4s var(--ease)'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '14px 16px 16px'
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: 'var(--text-h3)',
      fontWeight: 600,
      margin: '0 0 5px',
      color: hover ? 'var(--accent)' : 'var(--text-strong)',
      transition: 'color var(--dur) var(--ease)'
    }
  }, title), summary && /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-small)',
      color: 'var(--text-muted)',
      margin: '0 0 12px',
      lineHeight: 1.55
    }
  }, summary), tags.length > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '6px',
      flexWrap: 'wrap'
    }
  }, tags.map(t => /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    key: t,
    tone: "tag"
  }, t)))));
}
Object.assign(__ds_scope, { ProjectCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/ProjectCard.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Button — the site's primary action control.
 * Pill-shaped, seasonal-accent aware. Variants: primary | secondary | ghost.
 * An external link automatically gets the corner arrow used across the site.
 */
function Button({
  children,
  variant = 'primary',
  size = 'md',
  href,
  external = false,
  mono = false,
  disabled = false,
  onClick,
  style,
  ...rest
}) {
  const pad = size === 'sm' ? '7px 14px' : size === 'lg' ? '12px 26px' : '9px 20px';
  const fontSize = size === 'sm' ? '0.85rem' : size === 'lg' ? '1.02rem' : '0.94rem';
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '7px',
    padding: pad,
    fontSize,
    fontFamily: mono ? 'var(--font-mono)' : 'var(--font-sans)',
    fontWeight: 600,
    letterSpacing: mono ? 'var(--tracking-mono)' : '0.01em',
    lineHeight: 1,
    borderRadius: 'var(--radius-pill)',
    cursor: disabled ? 'not-allowed' : 'pointer',
    textDecoration: 'none',
    opacity: disabled ? 0.5 : 1,
    transition: 'background var(--dur) var(--ease), color var(--dur) var(--ease), border-color var(--dur) var(--ease), transform var(--dur) var(--ease), box-shadow var(--dur) var(--ease)',
    border: '1px solid transparent',
    whiteSpace: 'nowrap'
  };
  const variants = {
    primary: {
      background: 'var(--accent)',
      color: '#fff',
      boxShadow: 'var(--shadow-sm)'
    },
    secondary: {
      background: 'var(--accent-tint)',
      color: 'var(--accent)',
      borderColor: 'var(--accent-border)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--text-body)',
      borderColor: 'var(--line)'
    }
  };
  const [hover, setHover] = React.useState(false);
  const hoverStyle = !disabled && hover ? {
    primary: {
      background: 'var(--accent-hover)',
      transform: 'translateY(-1px)',
      boxShadow: 'var(--shadow-md)'
    },
    secondary: {
      background: 'var(--accent-tint-strong)',
      transform: 'translateY(-1px)'
    },
    ghost: {
      borderColor: 'var(--accent-border)',
      color: 'var(--accent)',
      transform: 'translateY(-1px)'
    }
  }[variant] : {};
  const arrow = external && /*#__PURE__*/React.createElement("svg", {
    width: "13",
    height: "13",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2.5",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M15 3h6v6"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M10 14L21 3"
  }));
  const props = {
    style: {
      ...base,
      ...variants[variant],
      ...hoverStyle,
      ...style
    },
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    onClick: disabled ? undefined : onClick,
    ...rest
  };
  if (href && !disabled) {
    return /*#__PURE__*/React.createElement("a", _extends({
      href: href
    }, external ? {
      target: '_blank',
      rel: 'noopener'
    } : {}, props), children, arrow);
  }
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    disabled: disabled
  }, props), children, arrow);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/SectionHeading.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * SectionHeading — serif H2 with a hairline rule and a short accent
 * underline segment. An optional monospace kicker (e.g. "// 02 ·
 * projects") sits above for the coding-touch rhythm.
 */
function SectionHeading({
  children,
  kicker,
  as = 'h2',
  style,
  ...rest
}) {
  const Tag = as;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      margin: '0 0 22px',
      ...style
    }
  }, rest), kicker && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '0.72rem',
      letterSpacing: 'var(--tracking-label)',
      textTransform: 'uppercase',
      color: 'var(--accent)',
      marginBottom: '8px'
    }
  }, kicker), /*#__PURE__*/React.createElement(Tag, {
    style: {
      position: 'relative',
      fontFamily: 'var(--font-serif)',
      fontWeight: 600,
      fontSize: 'var(--text-h2)',
      letterSpacing: 'var(--tracking-display)',
      color: 'var(--text-strong)',
      margin: 0,
      paddingBottom: '11px',
      borderBottom: '1px solid var(--line)'
    }
  }, children, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: 0,
      bottom: '-1px',
      width: '46px',
      height: '2px',
      background: 'var(--accent)',
      borderRadius: '2px'
    }
  })));
}
Object.assign(__ds_scope, { SectionHeading });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/SectionHeading.jsx", error: String((e && e.message) || e) }); }

// components/core/TerminalBlock.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * TerminalBlock — the signature coding-touch panel. A dark terminal
 * card with a title bar (traffic lights + prompt label), monospace
 * body, and an optional blinking cursor on the last line.
 *
 * Pass plain strings/JSX as children, or use <TerminalBlock.Line>.
 */
function TerminalBlock({
  title = 'amir@radmehr: ~',
  children,
  cursor = true,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      borderRadius: 'var(--radius-md)',
      overflow: 'hidden',
      border: '1px solid var(--line)',
      background: 'var(--surface-terminal)',
      boxShadow: 'var(--shadow-md)',
      fontFamily: 'var(--font-mono)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      padding: '10px 14px',
      background: 'rgba(255,255,255,0.04)',
      borderBottom: '1px solid rgba(255,255,255,0.07)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      gap: '6px'
    }
  }, /*#__PURE__*/React.createElement("i", {
    style: dot('#ff5f57')
  }), /*#__PURE__*/React.createElement("i", {
    style: dot('#febc2e')
  }), /*#__PURE__*/React.createElement("i", {
    style: dot('#28c840')
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: '6px',
      fontSize: '0.72rem',
      color: 'rgba(199,201,206,0.65)',
      letterSpacing: 'var(--tracking-mono)'
    }
  }, title)), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '16px 18px',
      fontSize: '0.82rem',
      lineHeight: 1.75,
      color: '#c7c9ce'
    }
  }, children, cursor && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-block',
      width: '8px',
      height: '15px',
      background: 'var(--accent)',
      verticalAlign: '-2px',
      marginLeft: '3px',
      animation: 'tb-blink 1.1s steps(1) infinite'
    }
  }), /*#__PURE__*/React.createElement("style", null, `@keyframes tb-blink{50%{opacity:0}}@media (prefers-reduced-motion:reduce){[style*="tb-blink"]{animation:none!important}}`)));
}
TerminalBlock.Line = function Line({
  prompt,
  comment,
  children
}) {
  return /*#__PURE__*/React.createElement("div", null, prompt && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--term-green)'
    }
  }, prompt), comment ? /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'rgba(199,201,206,0.5)'
    }
  }, children) : children);
};
function dot(c) {
  return {
    width: '11px',
    height: '11px',
    borderRadius: '50%',
    background: c,
    display: 'inline-block'
  };
}
Object.assign(__ds_scope, { TerminalBlock });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/TerminalBlock.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/app.jsx
try { (() => {
// App shell: season auto-detect (color palette only), light/dark toggle, router.
const {
  useState: uState,
  useEffect: uEffect
} = React;
function seasonFromMonth(m) {
  // N. Hemisphere: spring Mar–May, summer Jun–Aug, autumn Sep–Nov, winter Dec–Feb
  if (m >= 2 && m <= 4) return 'spring';
  if (m >= 5 && m <= 7) return 'summer';
  if (m >= 8 && m <= 10) return 'autumn';
  return 'winter';
}
function App() {
  const season = seasonFromMonth(new Date().getMonth());
  const [dark, setDark] = uState(true);
  const [page, setPage] = uState('Home');
  uEffect(() => {
    const b = document.body;
    b.classList.remove('season-spring', 'season-summer', 'season-autumn', 'season-winter');
    b.classList.add('season-' + season);
    b.classList.toggle('dark', dark);
  }, [season, dark]);
  const go = p => {
    setPage(p);
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };
  const Screen = window.Screens[page] || window.Screens.Home;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: '100vh',
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "grid-bg",
    style: {
      position: 'fixed',
      inset: 0,
      zIndex: -3
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'fixed',
      inset: 0,
      zIndex: -2,
      background: 'var(--season-grad)',
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement(window.Chrome.Nav, {
    active: page,
    onNav: go,
    dark: dark,
    onToggle: () => setDark(d => !d)
  }), /*#__PURE__*/React.createElement(Screen, {
    onNav: go
  }), /*#__PURE__*/React.createElement(window.Chrome.Footer, null));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/app.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/chrome.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
// Chrome (Nav, Footer, SocialIcons) + page screens for the website kit.
const {
  useState: useS
} = React;

/* ---------- Social icons (simple, consistent line/solid set) ---------- */
function SocialIcon({
  kind
}) {
  const c = {
    width: 18,
    height: 18,
    fill: 'none',
    stroke: 'currentColor',
    strokeWidth: 1.8,
    strokeLinecap: 'round',
    strokeLinejoin: 'round'
  };
  switch (kind) {
    case 'email':
      return /*#__PURE__*/React.createElement("svg", _extends({
        viewBox: "0 0 24 24"
      }, c), /*#__PURE__*/React.createElement("rect", {
        x: "2.5",
        y: "4.5",
        width: "19",
        height: "15",
        rx: "2.5"
      }), /*#__PURE__*/React.createElement("path", {
        d: "M3 6l9 6 9-6"
      }));
    case 'github':
      return /*#__PURE__*/React.createElement("svg", {
        viewBox: "0 0 24 24",
        width: "18",
        height: "18",
        fill: "currentColor"
      }, /*#__PURE__*/React.createElement("path", {
        d: "M12 2C6.48 2 2 6.58 2 12.25c0 4.53 2.87 8.37 6.84 9.73.5.1.68-.22.68-.49 0-.24-.01-.88-.01-1.73-2.78.62-3.37-1.37-3.37-1.37-.45-1.18-1.11-1.5-1.11-1.5-.91-.64.07-.62.07-.62 1 .07 1.53 1.06 1.53 1.06.89 1.56 2.34 1.11 2.91.85.09-.66.35-1.11.63-1.37-2.22-.26-4.56-1.14-4.56-5.07 0-1.12.39-2.03 1.03-2.75-.1-.26-.45-1.3.1-2.71 0 0 .84-.27 2.75 1.05A9.4 9.4 0 0112 6.84c.85 0 1.71.12 2.51.34 1.91-1.32 2.75-1.05 2.75-1.05.55 1.41.2 2.45.1 2.71.64.72 1.03 1.63 1.03 2.75 0 3.94-2.34 4.8-4.57 5.06.36.32.68.94.68 1.9 0 1.37-.01 2.47-.01 2.81 0 .27.18.6.69.49A10.04 10.04 0 0022 12.25C22 6.58 17.52 2 12 2z"
      }));
    case 'linkedin':
      return /*#__PURE__*/React.createElement("svg", {
        viewBox: "0 0 24 24",
        width: "18",
        height: "18",
        fill: "currentColor"
      }, /*#__PURE__*/React.createElement("path", {
        d: "M4.98 3.5a2.5 2.5 0 11-.02 5 2.5 2.5 0 01.02-5zM3 9h4v12H3zM9 9h3.8v1.64h.05c.53-.95 1.83-1.95 3.76-1.95C20.4 8.69 21 11.06 21 14.1V21h-4v-6.2c0-1.48-.03-3.38-2.06-3.38-2.06 0-2.38 1.6-2.38 3.27V21H9z"
      }));
    case 'scholar':
      return /*#__PURE__*/React.createElement("svg", {
        viewBox: "0 0 24 24",
        width: "18",
        height: "18",
        fill: "currentColor"
      }, /*#__PURE__*/React.createElement("path", {
        d: "M12 3L1 9l11 6 9-4.91V17h2V9zM5 13.18v3.5L12 20l7-3.32v-3.5L12 16.5z"
      }));
    case 'cv':
      return /*#__PURE__*/React.createElement("svg", _extends({
        viewBox: "0 0 24 24"
      }, c), /*#__PURE__*/React.createElement("path", {
        d: "M14 3H6.5A1.5 1.5 0 005 4.5v15A1.5 1.5 0 006.5 21h11a1.5 1.5 0 001.5-1.5V8z"
      }), /*#__PURE__*/React.createElement("path", {
        d: "M14 3v5h5M8.5 13h7M8.5 16.5h7"
      }));
    default:
      return null;
  }
}
function SocialRow({
  social,
  accentHover
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '8px',
      flexWrap: 'wrap'
    }
  }, social.map(s => /*#__PURE__*/React.createElement(SocialLink, {
    key: s.name,
    s: s
  })));
}
function SocialLink({
  s
}) {
  const [h, setH] = useS(false);
  return /*#__PURE__*/React.createElement("a", {
    href: s.url,
    title: s.name,
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '7px',
      padding: '7px 13px',
      borderRadius: 'var(--radius-pill)',
      border: `1px solid ${h ? 'var(--accent-border)' : 'var(--line)'}`,
      background: h ? 'var(--accent-tint)' : 'var(--surface-card)',
      color: h ? 'var(--accent)' : 'var(--text-muted)',
      textDecoration: 'none',
      fontSize: '0.84rem',
      fontWeight: 500,
      transform: h ? 'translateY(-1px)' : 'none',
      transition: 'all var(--dur) var(--ease)'
    }
  }, /*#__PURE__*/React.createElement(SocialIcon, {
    kind: s.kind
  }), s.name);
}

/* ---------- Sun / moon toggle ---------- */
function ThemeToggle({
  dark,
  onToggle
}) {
  return /*#__PURE__*/React.createElement("button", {
    onClick: onToggle,
    title: "Toggle light / dark",
    "aria-label": "Toggle theme",
    style: {
      display: 'grid',
      placeItems: 'center',
      width: '34px',
      height: '34px',
      borderRadius: '50%',
      border: '1px solid var(--line)',
      background: 'transparent',
      color: 'var(--text-muted)',
      cursor: 'pointer',
      transition: 'all var(--dur) var(--ease)'
    }
  }, dark ? /*#__PURE__*/React.createElement("svg", {
    width: "17",
    height: "17",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "4.2"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M19.1 4.9l-1.4 1.4M6.3 17.7l-1.4 1.4"
  })) : /*#__PURE__*/React.createElement("svg", {
    width: "16",
    height: "16",
    viewBox: "0 0 24 24",
    fill: "currentColor"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M21 12.8A9 9 0 1111.2 3a7 7 0 009.8 9.8z"
  })));
}

/* ---------- Nav ---------- */
function Nav({
  active,
  onNav,
  dark,
  onToggle
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 100,
      backdropFilter: 'saturate(1.6) blur(14px)',
      WebkitBackdropFilter: 'saturate(1.6) blur(14px)',
      background: dark ? 'linear-gradient(rgba(18,19,23,0.975), rgba(18,19,23,0.985)), url(../../assets/img/carpet-band.jpg) center / cover no-repeat' : 'linear-gradient(rgba(255,255,255,0.985), rgba(255,255,255,0.99)), url(../../assets/img/carpet-band.jpg) center / cover no-repeat',
      borderBottom: dark ? '1px solid rgba(255,255,255,0.08)' : '1px solid rgba(0,0,0,0.07)',
      boxShadow: dark ? '0 1px 12px rgba(0,0,0,0.28)' : '0 1px 12px rgba(20,24,40,0.1)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--nav-width)',
      margin: '0 auto',
      padding: '8px 20px',
      display: 'flex',
      alignItems: 'center',
      gap: '14px'
    }
  }, /*#__PURE__*/React.createElement("a", {
    onClick: () => onNav('Home'),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      fontFamily: 'var(--font-mono)',
      fontWeight: 600,
      fontSize: '15px',
      color: 'var(--text-strong)',
      cursor: 'pointer',
      whiteSpace: 'nowrap'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--accent)',
      marginRight: '6px'
    }
  }, "~/"), "amir"), /*#__PURE__*/React.createElement("nav", {
    style: {
      flex: 1,
      display: 'flex',
      justifyContent: 'center',
      gap: '2px',
      flexWrap: 'wrap'
    }
  }, window.SITE.nav.map(n => {
    const on = n === active;
    return /*#__PURE__*/React.createElement("a", {
      key: n,
      onClick: () => onNav(n),
      style: {
        cursor: 'pointer',
        padding: '6px 13px',
        borderRadius: 'var(--radius-pill)',
        fontSize: '14.5px',
        fontWeight: on ? 600 : 500,
        background: on ? 'var(--accent-tint-strong)' : 'transparent',
        color: on ? 'var(--accent)' : 'var(--text-muted)',
        transition: 'all var(--dur) var(--ease)'
      }
    }, n);
  })), /*#__PURE__*/React.createElement(ThemeToggle, {
    dark: dark,
    onToggle: onToggle
  }), /*#__PURE__*/React.createElement("img", {
    src: "../../assets/img/persian_flag_icon.svg",
    alt: "Iran",
    style: {
      height: '22px',
      width: '22px',
      borderRadius: '50%',
      objectFit: 'cover',
      boxShadow: '0 1px 3px rgba(0,0,0,0.2)'
    }
  })));
}

/* ---------- Footer ---------- */
function Footer() {
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      maxWidth: 'var(--wide-width)',
      margin: '48px auto 0',
      padding: '24px 20px 40px',
      borderTop: '1px solid var(--line)',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      flexWrap: 'wrap',
      gap: '12px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '0.74rem',
      color: 'var(--text-muted)',
      letterSpacing: 'var(--tracking-mono)'
    }
  }, "\xA9 2026 Amir Radmehr \xB7 built with Hugo"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '0.74rem',
      color: 'var(--text-muted)'
    }
  }, "aradmehr@umass.edu"));
}
window.Chrome = {
  Nav,
  Footer,
  SocialRow,
  SocialIcon
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/chrome.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/content.jsx
try { (() => {
// Site content — derived from amiradmehr.github.io (Hugo config + repos).
window.SITE = {
  name: 'Amir Radmehr',
  role: 'PhD Student · Computer Science',
  affil: 'University of Massachusetts Amherst',
  email: 'aradmehr@umass.edu',
  bio: 'I am a PhD student in Computer Science at UMass Amherst. My research focuses on cyber-physical systems, wearable health technologies, and intelligent sensors — currently building continuous blood-pressure monitoring systems at the Wireless and Sensor Systems Lab (WSSL).',
  currentWork: 'Developing innovative blood-pressure monitoring systems and wearable health technologies at the Wireless and Sensor Systems Lab (WSSL), UMass Amherst.',
  nav: ['Home', 'Papers', 'Projects', 'Blog', 'Teaching', 'Contact'],
  skills: ['Python', 'C / C++', 'MATLAB', 'Machine Learning', 'ESP-IDF', 'Embedded Systems', 'ROS', 'PyTorch', 'OpenCV', 'SolidWorks', 'PCB Design', '3D Printing', 'Git', 'Linux', 'Docker'],
  social: [{
    name: 'CV',
    kind: 'cv',
    url: '#'
  }, {
    name: 'Email',
    kind: 'email',
    url: 'mailto:aradmehr@umass.edu'
  }, {
    name: 'Scholar',
    kind: 'scholar',
    url: '#'
  }, {
    name: 'LinkedIn',
    kind: 'linkedin',
    url: '#'
  }, {
    name: 'GitHub',
    kind: 'github',
    url: '#'
  }],
  projects: [{
    title: 'RingBP',
    image: '../../assets/img/projects/ringbp.jpg',
    summary: 'A ring-form wearable that measures blood pressure continuously and streams it over BLE.',
    tags: ['wearables', 'ESP32', 'ML']
  }, {
    title: 'Vyre Data Stream',
    image: '../../assets/img/projects/vyre.jpg',
    summary: '100 Hz dual-channel force + pressure DAQ monitor — a React web app paired with ESP32-S3 firmware.',
    tags: ['embedded', 'React', 'BLE']
  }, {
    title: 'Human-Following Robot',
    image: '../../assets/img/projects/follower.jpg',
    summary: 'A mobile robot that tracks and follows a person using vision and onboard control.',
    tags: ['ROS', 'OpenCV', 'robotics']
  }, {
    title: 'BP Capture',
    image: '../../assets/img/projects/bp-capture.jpg',
    summary: 'Firmware + tooling to capture clean blood-pressure waveforms from a custom sensor front-end.',
    tags: ['firmware', 'XIAO', 'DAQ']
  }, {
    title: 'Particle-Filter Localization',
    image: '../../assets/img/projects/localization.jpg',
    summary: 'Monte-Carlo localization for a differential-drive robot on the Triton platform.',
    tags: ['robotics', 'estimation']
  }, {
    title: 'Pose Estimation NN',
    image: '../../assets/img/projects/pose-nn.jpg',
    summary: 'A neural network for real-time head-pose estimation from a single camera.',
    tags: ['ML', 'vision']
  }],
  posts: [{
    title: 'Sampling at 100 Hz on an ESP32-S3',
    date: 'Jan 2, 2026',
    summary: 'Notes on building a dual-channel DAQ pipeline that streams force and pressure over BLE without dropping samples.',
    tags: ['embedded', 'BLE'],
    read: '6 min'
  }, {
    title: 'Distilling a BP model for the edge',
    date: 'Nov 14, 2025',
    summary: 'Shrinking a blood-pressure regression network so it runs on-device, and what accuracy it costs.',
    tags: ['ML', 'edge'],
    read: '8 min'
  }, {
    title: 'Why I rebuilt my site with a seasonal theme',
    date: 'Sep 28, 2025',
    summary: 'A small pre-paint script reads the month and recolours the whole site. Here is how — and why it is fun.',
    tags: ['web', 'design'],
    read: '4 min'
  }],
  papers: [{
    title: 'Continuous Blood Pressure Estimation from a Ring-Form Wearable',
    authors: 'A. Radmehr, et al.',
    venue: 'IEEE BSN 2025',
    year: '2025',
    abstract: 'We present a ring-form factor wearable that estimates arterial blood pressure continuously from photoplethysmography and a calibrated pulse-transit model, validated against a clinical cuff across a cohort of participants.',
    tags: ['wearables', 'PPG', 'health']
  }, {
    title: 'On-Device Machine Learning for Wearable Cardiovascular Sensing',
    authors: 'A. Radmehr, et al.',
    venue: 'ACM IMWUT 2025',
    year: '2025',
    abstract: 'A study of model-distillation and quantization techniques that bring cardiovascular signal models onto resource-constrained microcontrollers while preserving clinical-grade accuracy.',
    tags: ['embedded-ML', 'edge']
  }, {
    title: 'A 100 Hz Dual-Channel DAQ for Force and Pressure',
    authors: 'A. Radmehr, et al.',
    venue: 'Workshop on Embedded Sensing 2024',
    year: '2024',
    abstract: 'The design and characterization of a low-cost, high-rate data-acquisition front-end for synchronized force and pressure capture over Bluetooth Low Energy.',
    tags: ['DAQ', 'BLE', 'sensors']
  }],
  teaching: [{
    code: 'COMPSCI 528',
    title: 'Mobile and Ubiquitous Computing',
    role: 'Teaching Assistant',
    term: 'Fall 2025'
  }, {
    code: 'COMPSCI 240',
    title: 'Reasoning Under Uncertainty',
    role: 'Teaching Assistant',
    term: 'Spring 2025'
  }]
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/content.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/screens.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
// Page screens: Home, Papers, Projects, Blog, Teaching, Contact.
const {
  useState: uS
} = React;
const SECTION = {
  maxWidth: 'var(--wide-width)',
  margin: '0 auto',
  padding: '34px 20px 12px'
};

/* ============================ HOME ============================ */
function Home({
  onNav
}) {
  const S = window.SITE;
  const {
    Button,
    Badge,
    SectionHeading,
    TerminalBlock,
    TLine,
    ProjectCard,
    PostCard
  } = window;
  return /*#__PURE__*/React.createElement("main", null, /*#__PURE__*/React.createElement("section", {
    style: {
      ...SECTION,
      paddingTop: '46px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "hero-grid",
    style: {
      display: 'grid',
      gridTemplateColumns: '1.45fr 1fr',
      gap: '40px',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '0.74rem',
      letterSpacing: 'var(--tracking-label)',
      textTransform: 'uppercase',
      color: 'var(--accent)',
      marginBottom: '14px'
    }
  }, "// phd \xB7 computer science \xB7 umass amherst"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-serif)',
      fontWeight: 600,
      fontSize: 'var(--text-hero)',
      lineHeight: 1.04,
      letterSpacing: 'var(--tracking-display)',
      color: 'var(--text-strong)',
      margin: '0 0 18px'
    }
  }, "Amir Radmehr", /*#__PURE__*/React.createElement("span", {
    className: "tb-cursor",
    style: {
      display: 'inline-block',
      width: '5px',
      height: '0.78em',
      background: 'var(--accent)',
      marginLeft: '6px',
      verticalAlign: 'baseline'
    }
  })), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: '1.06rem',
      lineHeight: 1.7,
      color: 'var(--text-body)',
      margin: '0 0 22px',
      maxWidth: '46ch'
    }
  }, S.bio), /*#__PURE__*/React.createElement(window.Chrome.SocialRow, {
    social: S.social
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '16px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/img/me.jpeg",
    alt: "Amir Radmehr",
    style: {
      width: '100%',
      aspectRatio: '1/1',
      objectFit: 'cover',
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-lg)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: '12px',
      bottom: '12px',
      fontFamily: 'var(--font-mono)',
      fontSize: '0.68rem',
      color: '#fff',
      background: 'rgba(0,0,0,0.55)',
      padding: '4px 9px',
      borderRadius: 'var(--radius-xs)',
      backdropFilter: 'blur(4px)'
    }
  }, "./me.jpeg"))))), /*#__PURE__*/React.createElement("section", {
    style: SECTION
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    kicker: "// 01 \xB7 status"
  }, "Currently Working On"), /*#__PURE__*/React.createElement(TerminalBlock, {
    title: "amir@radmehr: ~/wssl"
  }, /*#__PURE__*/React.createElement(TLine, {
    prompt: "$ "
  }, "cat now.md"), /*#__PURE__*/React.createElement(TLine, {
    comment: true
  }, "# updated this term"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: '4px'
    }
  }, S.currentWork))), /*#__PURE__*/React.createElement("section", {
    style: SECTION
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    kicker: "// 02 \xB7 stack"
  }, "Skills & Tools"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: '8px'
    }
  }, S.skills.map(s => /*#__PURE__*/React.createElement(Badge, {
    key: s
  }, s)))), /*#__PURE__*/React.createElement("section", {
    style: SECTION
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    kicker: "// 03 \xB7 projects"
  }, "Featured Projects"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))',
      gap: '18px'
    }
  }, S.projects.slice(0, 3).map(p => /*#__PURE__*/React.createElement(ProjectCard, _extends({
    key: p.title
  }, p, {
    onClick: () => onNav('Projects')
  }))))), /*#__PURE__*/React.createElement("section", {
    style: SECTION
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    kicker: "// 04 \xB7 writing"
  }, "Recent Posts"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '12px'
    }
  }, S.posts.map(p => /*#__PURE__*/React.createElement(PostCard, _extends({
    key: p.title
  }, p, {
    onClick: () => onNav('Blog')
  }))))));
}

/* ============================ PAPERS (split pane) ============================ */
function Papers() {
  const S = window.SITE;
  const {
    Badge
  } = window;
  const [sel, setSel] = uS(0);
  const p = S.papers[sel];
  return /*#__PURE__*/React.createElement("main", {
    style: {
      maxWidth: 'var(--nav-width)',
      margin: '0 auto',
      padding: '0 20px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '300px 1fr',
      gap: '0',
      minHeight: '70vh',
      borderLeft: '1px solid var(--line)',
      borderRight: '1px solid var(--line)'
    }
  }, /*#__PURE__*/React.createElement("aside", {
    style: {
      borderRight: '1px solid var(--line)',
      padding: '24px 0',
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-serif)',
      fontSize: '1.3rem',
      fontWeight: 600,
      padding: '0 20px 16px',
      margin: 0,
      borderBottom: '1px solid var(--line)',
      color: 'var(--text-strong)'
    }
  }, "Papers"), S.papers.map((pp, i) => {
    const on = i === sel;
    return /*#__PURE__*/React.createElement("button", {
      key: pp.title,
      onClick: () => setSel(i),
      style: {
        textAlign: 'left',
        padding: '14px 20px',
        border: 'none',
        borderLeft: `3px solid ${on ? 'var(--accent)' : 'transparent'}`,
        background: on ? 'var(--accent-tint)' : 'transparent',
        cursor: 'pointer',
        font: 'inherit',
        display: 'flex',
        flexDirection: 'column',
        gap: '4px',
        transition: 'all .2s ease'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: '0.9rem',
        fontWeight: 600,
        lineHeight: 1.4,
        color: on ? 'var(--text-strong)' : 'var(--text-muted)'
      }
    }, pp.title), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: '0.72rem',
        opacity: 0.7,
        color: 'var(--text-muted)'
      }
    }, pp.venue));
  })), /*#__PURE__*/React.createElement("article", {
    style: {
      padding: '28px 40px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      borderBottom: '1px solid var(--line)',
      paddingBottom: '16px',
      marginBottom: '20px'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-serif)',
      fontSize: '1.5rem',
      fontWeight: 600,
      lineHeight: 1.35,
      margin: '0 0 10px',
      color: 'var(--text-strong)'
    }
  }, p.title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '0.9rem',
      color: 'var(--text-muted)',
      marginBottom: '10px'
    }
  }, p.authors), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-block',
      fontFamily: 'var(--font-mono)',
      fontSize: '0.76rem',
      padding: '4px 10px',
      borderRadius: 'var(--radius-xs)',
      background: 'var(--surface-sunken)',
      color: 'var(--text-muted)'
    }
  }, p.venue, " \xB7 ", p.year)), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: '1.02rem',
      lineHeight: 1.75,
      color: 'var(--text-body)',
      margin: '0 0 20px',
      maxWidth: '62ch'
    }
  }, p.abstract), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '6px',
      flexWrap: 'wrap'
    }
  }, p.tags.map(t => /*#__PURE__*/React.createElement(Badge, {
    key: t,
    tone: "tag"
  }, t))))));
}

/* ============================ PROJECTS ============================ */
function Projects() {
  const S = window.SITE;
  const {
    SectionHeading,
    ProjectCard
  } = window;
  return /*#__PURE__*/React.createElement("main", {
    style: SECTION
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    kicker: "// projects \xB7 06"
  }, "Projects"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fill, minmax(250px, 1fr))',
      gap: '18px'
    }
  }, S.projects.map(p => /*#__PURE__*/React.createElement(ProjectCard, _extends({
    key: p.title
  }, p)))));
}

/* ============================ BLOG ============================ */
function Blog() {
  const S = window.SITE;
  const {
    SectionHeading,
    PostCard
  } = window;
  return /*#__PURE__*/React.createElement("main", {
    style: SECTION
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    kicker: "// blog \xB7 log"
  }, "Blog"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '12px'
    }
  }, S.posts.map(p => /*#__PURE__*/React.createElement(PostCard, _extends({
    key: p.title
  }, p)))));
}

/* ============================ TEACHING ============================ */
function Teaching() {
  const S = window.SITE;
  const {
    SectionHeading,
    Badge
  } = window;
  return /*#__PURE__*/React.createElement("main", {
    style: SECTION
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    kicker: "// teaching"
  }, "Teaching"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '12px'
    }
  }, S.teaching.map(t => /*#__PURE__*/React.createElement("div", {
    key: t.code,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '16px',
      padding: '18px 22px',
      borderRadius: 'var(--radius-md)',
      background: 'var(--surface-card)',
      border: '1px solid var(--line)',
      boxShadow: 'var(--shadow-sm)'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "mono"
  }, t.code), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '1.02rem',
      fontWeight: 600,
      color: 'var(--text-strong)'
    }
  }, t.title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '0.86rem',
      color: 'var(--text-muted)'
    }
  }, t.role)), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '0.78rem',
      color: 'var(--text-muted)'
    }
  }, t.term)))));
}

/* ============================ CONTACT ============================ */
function Field({
  label,
  ...props
}) {
  const [f, setF] = uS(false);
  const common = {
    width: '100%',
    padding: '11px 13px',
    fontFamily: 'var(--font-sans)',
    fontSize: '0.95rem',
    color: 'var(--text-body)',
    background: 'var(--surface-page)',
    borderRadius: 'var(--radius-sm)',
    border: `1px solid ${f ? 'var(--accent-border)' : 'var(--line)'}`,
    outline: 'none',
    boxShadow: f ? '0 0 0 3px var(--accent-tint)' : 'none',
    transition: 'all var(--dur) var(--ease)',
    boxSizing: 'border-box'
  };
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'block',
      marginBottom: '14px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      fontFamily: 'var(--font-mono)',
      fontSize: '0.72rem',
      letterSpacing: 'var(--tracking-mono)',
      color: 'var(--text-muted)',
      marginBottom: '6px'
    }
  }, label), props.textarea ? /*#__PURE__*/React.createElement("textarea", _extends({}, props, {
    onFocus: () => setF(true),
    onBlur: () => setF(false),
    style: {
      ...common,
      minHeight: '110px',
      resize: 'vertical',
      font: 'inherit'
    }
  })) : /*#__PURE__*/React.createElement("input", _extends({}, props, {
    onFocus: () => setF(true),
    onBlur: () => setF(false),
    style: common
  })));
}
function Contact() {
  const S = window.SITE;
  const {
    SectionHeading,
    Button,
    TerminalBlock,
    TLine
  } = window;
  const [name, setName] = uS('');
  const [from, setFrom] = uS('');
  const [msg, setMsg] = uS('');
  const [sent, setSent] = uS(false);
  const send = e => {
    e.preventDefault();
    const subject = encodeURIComponent(`Website message from ${name || 'someone'}`);
    const body = encodeURIComponent(`${msg}\n\n— ${name}${from ? ` (${from})` : ''}`);
    window.location.href = `mailto:${S.email}?subject=${subject}&body=${body}`;
    setSent(true);
  };
  return /*#__PURE__*/React.createElement("main", {
    style: SECTION
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    kicker: "// contact"
  }, "Get in touch"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '0.85fr 1fr',
      gap: '24px',
      alignItems: 'start'
    },
    className: "contact-grid"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(TerminalBlock, {
    title: "amir@radmehr: ~/contact",
    cursor: false
  }, /*#__PURE__*/React.createElement(TLine, {
    prompt: "$ "
  }, "whoami --contact"), /*#__PURE__*/React.createElement(TLine, {
    comment: true
  }, "# the fastest way to reach me"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: '6px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--term-blue)'
    }
  }, "email"), " = \"", S.email, "\""), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--term-blue)'
    }
  }, "office"), " = \"WSSL \xB7 UMass Amherst\""), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--term-blue)'
    }
  }, "reply"), " = \"within ~2 days\"")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: '0.95rem',
      lineHeight: 1.65,
      color: 'var(--text-muted)',
      margin: '16px 2px 0'
    }
  }, "Happy to talk about wearable sensing, embedded ML, or collaborations.")), /*#__PURE__*/React.createElement("form", {
    onSubmit: send,
    style: {
      padding: '22px 24px',
      borderRadius: 'var(--radius-md)',
      background: 'var(--surface-card)',
      border: '1px solid var(--line)',
      boxShadow: 'var(--shadow-sm)'
    }
  }, sent ? /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '24px 8px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '0.8rem',
      color: 'var(--term-green)',
      marginBottom: '10px'
    }
  }, "$ message --send \u2713"), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-serif)',
      fontSize: '1.25rem',
      fontWeight: 600,
      color: 'var(--text-strong)',
      margin: '0 0 8px'
    }
  }, "Your email is ready to send"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: '0.92rem',
      color: 'var(--text-muted)',
      margin: '0 0 18px',
      lineHeight: 1.6
    }
  }, "Your mail app just opened with the message drafted to ", S.email, ". Hit send there and it lands in my inbox."), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    onClick: () => setSent(false)
  }, "Write another")) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '0.72rem',
      letterSpacing: 'var(--tracking-label)',
      textTransform: 'uppercase',
      color: 'var(--accent)',
      marginBottom: '16px'
    }
  }, "// send a message"), /*#__PURE__*/React.createElement(Field, {
    label: "name",
    placeholder: "Your name",
    value: name,
    onChange: e => setName(e.target.value),
    required: true
  }), /*#__PURE__*/React.createElement(Field, {
    label: "email",
    type: "email",
    placeholder: "you@example.com",
    value: from,
    onChange: e => setFrom(e.target.value),
    required: true
  }), /*#__PURE__*/React.createElement(Field, {
    label: "message",
    textarea: true,
    placeholder: "What's on your mind?",
    value: msg,
    onChange: e => setMsg(e.target.value),
    required: true
  }), /*#__PURE__*/React.createElement(Button, {
    type: "submit",
    onClick: send,
    style: {
      width: '100%',
      justifyContent: 'center'
    }
  }, "Send message")))));
}
window.Screens = {
  Home,
  Papers,
  Projects,
  Blog,
  Teaching,
  Contact
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/screens.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/ui.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
// Shared cosmetic primitives for the website UI kit.
// Mirror the design-system components but self-contained so the kit
// renders independent of the compiled bundle. Exposed on window.

const {
  useState
} = React;
function Button({
  children,
  variant = 'primary',
  size = 'md',
  href,
  external,
  mono,
  onClick,
  style
}) {
  const [h, setH] = useState(false);
  const pad = size === 'sm' ? '7px 14px' : size === 'lg' ? '12px 26px' : '9px 18px';
  const fs = size === 'sm' ? '0.85rem' : size === 'lg' ? '1.02rem' : '0.92rem';
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '7px',
    padding: pad,
    fontSize: fs,
    fontFamily: mono ? 'var(--font-mono)' : 'var(--font-sans)',
    fontWeight: 600,
    letterSpacing: mono ? 'var(--tracking-mono)' : '0.01em',
    lineHeight: 1,
    borderRadius: 'var(--radius-pill)',
    cursor: 'pointer',
    textDecoration: 'none',
    border: '1px solid transparent',
    whiteSpace: 'nowrap',
    transition: 'all var(--dur) var(--ease)'
  };
  const v = {
    primary: {
      background: 'var(--accent)',
      color: '#fff',
      boxShadow: 'var(--shadow-sm)'
    },
    secondary: {
      background: 'var(--accent-tint)',
      color: 'var(--accent)',
      borderColor: 'var(--accent-border)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--text-body)',
      borderColor: 'var(--line)'
    }
  }[variant];
  const hov = h ? {
    primary: {
      background: 'var(--accent-hover)',
      transform: 'translateY(-1px)',
      boxShadow: 'var(--shadow-md)'
    },
    secondary: {
      background: 'var(--accent-tint-strong)',
      transform: 'translateY(-1px)'
    },
    ghost: {
      borderColor: 'var(--accent-border)',
      color: 'var(--accent)',
      transform: 'translateY(-1px)'
    }
  }[variant] : {};
  const arrow = external && /*#__PURE__*/React.createElement("svg", {
    width: "13",
    height: "13",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M15 3h6v6"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M10 14L21 3"
  }));
  const p = {
    style: {
      ...base,
      ...v,
      ...hov,
      ...style
    },
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    onClick
  };
  return href ? /*#__PURE__*/React.createElement("a", _extends({
    href: href
  }, external ? {
    target: '_blank',
    rel: 'noopener'
  } : {}, p), children, arrow) : /*#__PURE__*/React.createElement("button", p, children, arrow);
}
function Badge({
  children,
  tone = 'skill',
  style
}) {
  const [h, setH] = useState(false);
  const t = {
    skill: {
      padding: '6px 13px',
      borderRadius: 'var(--radius-pill)',
      background: 'var(--surface-sunken)',
      border: '1px solid var(--line)',
      color: 'var(--text-muted)',
      fontSize: '0.84rem',
      fontWeight: 500,
      ...(h ? {
        background: 'var(--accent-tint)',
        borderColor: 'var(--accent-border)',
        color: 'var(--accent)',
        transform: 'translateY(-2px)'
      } : {})
    },
    tag: {
      padding: '3px 11px',
      borderRadius: 'var(--radius-pill)',
      background: 'var(--accent-tint)',
      color: 'var(--accent)',
      fontSize: '0.74rem',
      fontWeight: 500
    },
    mono: {
      padding: '4px 9px',
      borderRadius: 'var(--radius-xs)',
      background: 'var(--surface-sunken)',
      border: '1px solid var(--line)',
      color: 'var(--text-muted)',
      fontFamily: 'var(--font-mono)',
      fontSize: '0.72rem',
      letterSpacing: 'var(--tracking-mono)'
    }
  }[tone];
  return /*#__PURE__*/React.createElement("span", {
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      lineHeight: 1,
      whiteSpace: 'nowrap',
      transition: 'all var(--dur) var(--ease)',
      ...t,
      ...style
    }
  }, children);
}
function SectionHeading({
  children,
  kicker
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      margin: '0 0 22px'
    }
  }, kicker && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '0.72rem',
      letterSpacing: 'var(--tracking-label)',
      textTransform: 'uppercase',
      color: 'var(--accent)',
      marginBottom: '8px'
    }
  }, kicker), /*#__PURE__*/React.createElement("h2", {
    style: {
      position: 'relative',
      fontFamily: 'var(--font-serif)',
      fontWeight: 600,
      fontSize: 'var(--text-h2)',
      letterSpacing: 'var(--tracking-display)',
      color: 'var(--text-strong)',
      margin: 0,
      paddingBottom: '11px',
      borderBottom: '1px solid var(--line)'
    }
  }, children, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: 0,
      bottom: '-1px',
      width: '46px',
      height: '2px',
      background: 'var(--accent)',
      borderRadius: '2px'
    }
  })));
}
function TerminalBlock({
  title = 'amir@radmehr: ~',
  children,
  cursor = true,
  style
}) {
  const dot = c => ({
    width: '11px',
    height: '11px',
    borderRadius: '50%',
    background: c,
    display: 'inline-block'
  });
  return /*#__PURE__*/React.createElement("div", {
    style: {
      borderRadius: 'var(--radius-md)',
      overflow: 'hidden',
      border: '1px solid var(--line)',
      background: 'var(--surface-terminal)',
      boxShadow: 'var(--shadow-md)',
      fontFamily: 'var(--font-mono)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      padding: '10px 14px',
      background: 'rgba(255,255,255,0.04)',
      borderBottom: '1px solid rgba(255,255,255,0.07)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      gap: '6px'
    }
  }, /*#__PURE__*/React.createElement("i", {
    style: dot('#ff5f57')
  }), /*#__PURE__*/React.createElement("i", {
    style: dot('#febc2e')
  }), /*#__PURE__*/React.createElement("i", {
    style: dot('#28c840')
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: '6px',
      fontSize: '0.72rem',
      color: 'rgba(199,201,206,0.65)',
      letterSpacing: 'var(--tracking-mono)'
    }
  }, title)), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '16px 18px',
      fontSize: '0.84rem',
      lineHeight: 1.8,
      color: '#c7c9ce'
    }
  }, children, cursor && /*#__PURE__*/React.createElement("span", {
    className: "tb-cursor",
    style: {
      display: 'inline-block',
      width: '8px',
      height: '15px',
      background: 'var(--accent)',
      verticalAlign: '-2px',
      marginLeft: '3px'
    }
  })));
}
function TLine({
  prompt,
  comment,
  children
}) {
  return /*#__PURE__*/React.createElement("div", null, prompt && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--term-green)'
    }
  }, prompt), comment ? /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'rgba(199,201,206,0.5)'
    }
  }, children) : children);
}
function ProjectCard({
  title,
  summary,
  image,
  cover,
  tags = [],
  onClick
}) {
  const [h, setH] = useState(false);
  return /*#__PURE__*/React.createElement("a", {
    onClick: onClick,
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    style: {
      display: 'flex',
      flexDirection: 'column',
      borderRadius: 'var(--radius-md)',
      background: 'var(--surface-card)',
      cursor: 'pointer',
      border: `1px solid ${h ? 'var(--accent-border)' : 'var(--line)'}`,
      boxShadow: h ? 'var(--shadow-lg)' : 'var(--shadow-sm)',
      overflow: 'hidden',
      textDecoration: 'none',
      transform: h ? 'translateY(-4px)' : 'none',
      transition: 'all var(--dur) var(--ease)'
    }
  }, image ? /*#__PURE__*/React.createElement("div", {
    style: {
      height: '150px',
      overflow: 'hidden',
      background: 'var(--surface-sunken)'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: image,
    alt: title,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      transform: h ? 'scale(1.06)' : 'none',
      transition: 'transform 0.4s var(--ease)'
    }
  })) : /*#__PURE__*/React.createElement("div", {
    className: "grid-bg",
    style: {
      height: '136px',
      display: 'flex',
      alignItems: 'flex-end',
      padding: '12px',
      background: 'linear-gradient(150deg, var(--accent-tint) 0%, var(--surface-sunken) 70%)',
      borderBottom: '1px solid var(--line)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '0.7rem',
      color: 'var(--text-muted)',
      background: 'var(--surface-card)',
      padding: '3px 8px',
      borderRadius: 'var(--radius-xs)',
      border: '1px solid var(--line)'
    }
  }, cover || './cover.jpg')), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '14px 16px 16px'
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: 'var(--text-h3)',
      fontWeight: 600,
      margin: '0 0 5px',
      color: h ? 'var(--accent)' : 'var(--text-strong)',
      transition: 'color var(--dur) var(--ease)'
    }
  }, title), summary && /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-small)',
      color: 'var(--text-muted)',
      margin: '0 0 12px',
      lineHeight: 1.55
    }
  }, summary), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '6px',
      flexWrap: 'wrap'
    }
  }, tags.map(t => /*#__PURE__*/React.createElement(Badge, {
    key: t,
    tone: "tag"
  }, t)))));
}
function PostCard({
  title,
  summary,
  date,
  tags = [],
  onClick
}) {
  const [h, setH] = useState(false);
  return /*#__PURE__*/React.createElement("a", {
    onClick: onClick,
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    style: {
      display: 'block',
      padding: '18px 22px',
      borderRadius: 'var(--radius-md)',
      background: 'var(--surface-card)',
      cursor: 'pointer',
      border: `1px solid ${h ? 'var(--accent-border)' : 'var(--line)'}`,
      boxShadow: h ? 'var(--shadow-lg)' : 'var(--shadow-sm)',
      textDecoration: 'none',
      transform: h ? 'translateY(-3px)' : 'none',
      transition: 'all var(--dur) var(--ease)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '10px',
      flexWrap: 'wrap'
    }
  }, date && /*#__PURE__*/React.createElement("time", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-meta)',
      color: 'var(--text-muted)',
      letterSpacing: 'var(--tracking-mono)'
    }
  }, date), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      gap: '6px'
    }
  }, tags.map(t => /*#__PURE__*/React.createElement(Badge, {
    key: t,
    tone: "tag"
  }, t)))), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: '1.08rem',
      fontWeight: 600,
      margin: '7px 0 4px',
      color: h ? 'var(--accent)' : 'var(--text-strong)',
      transition: 'color var(--dur) var(--ease)'
    }
  }, title), summary && /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-small)',
      color: 'var(--text-muted)',
      margin: 0,
      lineHeight: 1.55
    }
  }, summary));
}
Object.assign(window, {
  Button,
  Badge,
  SectionHeading,
  TerminalBlock,
  TLine,
  ProjectCard,
  PostCard
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/ui.jsx", error: String((e && e.message) || e) }); }

__ds_ns.PostCard = __ds_scope.PostCard;

__ds_ns.ProjectCard = __ds_scope.ProjectCard;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.SectionHeading = __ds_scope.SectionHeading;

__ds_ns.TerminalBlock = __ds_scope.TerminalBlock;

})();
